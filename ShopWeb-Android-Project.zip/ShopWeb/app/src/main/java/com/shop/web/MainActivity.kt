package com.shop.web

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.WindowCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject

/** ওয়েবসাইটের ঠিকানা বদলাতে হলে শুধু এই লাইনটি বদলান */
const val SITE_URL = "https://onlinecomputer724.infinityfree.me/"

private const val TEAL = "#087A6C"

/** সাইটের window.print() অ্যাপের প্রিন্ট/PDF-সেভ ডায়ালগে পাঠায় (ইনভয়েস প্রিন্টের জন্য) */
private const val PRINT_JS = "window.print=function(){try{AndroidBridge.print();}catch(e){}};"

private const val HOOK_JS = """(function(){
 var f=document.querySelector('input[type=password]'); if(!f||!f.form||f.form.__hooked) return;
 f.form.__hooked=true;
 f.form.addEventListener('submit',function(){
   var u=f.form.querySelector('input[name=username]');
   AndroidBridge.saveLogin(u?u.value:'', f.value);
 });
})()"""

private const val OFFLINE_HTML = """<html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;font-family:sans-serif;background:#f1f7f5;display:flex;align-items:center;justify-content:center;min-height:100vh">
<div style="text-align:center;padding:32px 24px">
<div style="width:84px;height:84px;margin:0 auto 20px;border-radius:24px;background:#087a6c;color:#fff;font-size:44px;line-height:84px">!</div>
<h2 style="color:#0b4f49;margin:0 0 8px">ইন্টারনেট সংযোগ নেই</h2>
<p style="color:#5b6b67;margin:0 0 24px">নেট চালু করে আবার চেষ্টা করুন।</p>
<a href="$SITE_URL" style="display:inline-block;padding:14px 32px;background:#087a6c;color:#fff;border-radius:28px;text-decoration:none;font-weight:600">আবার চেষ্টা করুন</a>
</div></body></html>"""

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var progress: ProgressBar
    private var store: SharedPreferences? = null
    private val siteHost: String? = Uri.parse(SITE_URL).host

    @Volatile private var pending: Pair<String, String>? = null
    private var autoTries = 0
    private var justLoggedIn = false

    inner class Bridge {
        @JavascriptInterface
        fun saveLogin(u: String?, p: String?) {
            if (!u.isNullOrBlank() && !p.isNullOrEmpty()) pending = u to p
        }

        @JavascriptInterface
        fun print() {
            runOnUiThread {
                val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                pm.print("Document", web.createPrintDocumentAdapter("Document"), PrintAttributes.Builder().build())
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // পাসওয়ার্ড এনক্রিপ্ট করে ফোনে রাখা হয়; কোনো কারণে না পারলে সেভ বন্ধ থাকবে
        store = try {
            val key = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(
                this, "login_store", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) { null }

        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        web = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.textZoom = 100
        }
        swipe = SwipeRefreshLayout(this).apply {
            addView(web, ViewGroup.LayoutParams(mp, mp))
            setColorSchemeColors(Color.parseColor(TEAL))
            setOnRefreshListener { web.reload() }
            setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
            progressTintList = ColorStateList.valueOf(Color.parseColor("#FFC107"))
            progressBackgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
        }
        val root = FrameLayout(this)
        root.addView(swipe, FrameLayout.LayoutParams(mp, mp))
        root.addView(progress, FrameLayout.LayoutParams(mp, dp(3)))
        setContentView(root)
        window.setBackgroundDrawable(ColorDrawable(Color.WHITE)) // স্প্ল্যাশের সবুজ ব্যাকগ্রাউন্ড সরানো
        WindowCompat.getInsetsController(window, root).isAppearanceLightNavigationBars = true

        CookieManager.getInstance().setAcceptCookie(true)
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(web, PRINT_JS, setOf("https://$siteHost"))
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                progress.progress = p
                progress.visibility = if (p < 100) View.VISIBLE else View.GONE
                if (p == 100) swipe.isRefreshing = false
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val uri = r.url
                if ((uri.scheme == "http" || uri.scheme == "https") && uri.host == siteHost) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
                return true
            }

            override fun onPageStarted(v: WebView, url: String, favicon: Bitmap?) {
                val u = Uri.parse(url)
                // লগআউট করলে সেভ করা পাসওয়ার্ড মুছে যায়, নইলে সাথে সাথে আবার ঢুকে যেত
                if (u.host == siteHost && (u.path ?: "").trimEnd('/').endsWith("logout")) {
                    store?.edit()?.clear()?.apply()
                    pending = null
                }
            }

            override fun onPageFinished(v: WebView, url: String) {
                CookieManager.getInstance().flush()
                swipe.isRefreshing = false
                if (Uri.parse(url).host != siteHost) return
                v.evaluateJavascript(PRINT_JS, null)
                v.evaluateJavascript(HOOK_JS, null)
                v.evaluateJavascript("!!document.querySelector('input[type=password]')") { isLogin ->
                    if (isLogin == "true") {
                        if (pending != null) {
                            pending = null // হাতে লিখে লগইন ব্যর্থ হয়েছে, অটো-ফিল নয়
                        } else {
                            val u = store?.getString("u", null)
                            val p = store?.getString("p", null)
                            if (u != null && p != null && autoTries < 2) {
                                autoTries++
                                justLoggedIn = true
                                v.evaluateJavascript(fillJs(u, p), null)
                            }
                        }
                    } else {
                        autoTries = 0
                        pending?.let {
                            store?.edit()?.putString("u", it.first)?.putString("p", it.second)?.apply()
                            pending = null
                            justLoggedIn = true
                        }
                        if (justLoggedIn) { v.clearHistory(); justLoggedIn = false }
                    }
                }
            }

            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (r.isForMainFrame) {
                    swipe.isRefreshing = false
                    v.loadDataWithBaseURL(null, OFFLINE_HTML, "text/html", "UTF-8", null)
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else finish() }
        })

        web.loadUrl(SITE_URL)
    }

    private fun fillJs(u: String, p: String) =
        "(function(){var f=document.querySelector('input[type=password]');if(!f||!f.form)return;" +
        "var x=f.form.querySelector('input[name=username]');if(x)x.value=${JSONObject.quote(u)};" +
        "f.value=${JSONObject.quote(p)};f.form.submit();})()"

    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
